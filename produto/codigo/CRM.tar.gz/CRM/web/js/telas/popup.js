$("div.botao-fechar").live("click", function() {
    $("#shadow").css("display", "none");
    $("div.popup").css("display", "none");
    $("div.popup-convite").css("display", "none");
});